import APIHelper from "../../context/ApiHelper";
import API from "../../constants/API";
import { Download } from "lucide-react";

const IdeaGenFormService = {
  GetIdeaGenNo: async () => {
    try {
      const response = await APIHelper("POST", API.IdeaGenForm.GetIdeaGenNo);
      return response;
    } catch (error) {
      console.error("Error fetching req number:", error);
      throw error;
    }
  },

  GetComplaintRegion: async () => {
    try {
      const response = await APIHelper(
        "POST",
        API.ComplaintForm.GetComplaintRegion,
      );
      return response;
    } catch (error) {
      console.error("Error fetching complaint regions:", error);
      throw error;
    }
  },

  GetComplaintSerialDetails: async (serialNo) => {
    try {
      const response = await APIHelper(
        "POST",
        API.ComplaintForm.GetComplaintSerialDetails,
        serialNo,
      );
      return response;
    } catch (error) {
      console.error("Error fetching serial details:", error);
      throw error;
    }
  },
  GetComplaintWhoCommissioned: async () => {
    try {
      const response = await APIHelper(
        "POST",
        API.ComplaintForm.GetComplaintWhoCommissioned,
      );
      return response;
    } catch (error) {
      console.error("Error fetching who commissioned data:", error);
      throw error;
    }
  },

  GetComplaintSiteConditions: async () => {
    try {
      const response = await APIHelper(
        "POST",
        API.ComplaintForm.GetComplaintSiteConditions,
      );
      return response;
    } catch (error) {
      console.error("Error fetching site conditions:", error);
      throw error;
    }
  },

  GetComplaintSiteConditionSecondary: async () => {
    try {
      const response = await APIHelper(
        "POST",
        API.ComplaintForm.GetComplaintSiteConditionSecondary,
      );
      return response;
    } catch (error) {
      console.error("Error fetching secondary site conditions:", error);
      throw error;
    }
  },

  GetComplaintTypeOfLoadLifted: async () => {
    try {
      const response = await APIHelper(
        "POST",
        API.ComplaintForm.GetComplaintTypeOfLoadLifted,
      );
      return response;
    } catch (error) {
      console.error("Error fetching type of load lifted data:", error);
      throw error;
    }
  },

  GetComplaintRelatedToCategories: async () => {
    try {
      const response = await APIHelper(
        "POST",
        API.ComplaintForm.GetComplaintRelatedToCategories,
      );
      return response;
    } catch (error) {
      console.error("Error fetching related to categories:", error);
      throw error;
    }
  },

  GetComplaintSpecificIssuesByCategory: async (categoryId) => {
    try {
      const response = await APIHelper(
        "POST",
        API.ComplaintForm.GetComplaintSpecificIssuesByCategory,
        {
          complaint_Category_Id: categoryId,
        },
      );
      return response;
    } catch (error) {
      console.error("Error fetching specific issues by category:", error);
      throw error;
    }
  },

  SubmitComplaintForm: async (jsonData) => {
    try {
      const response = await APIHelper(
        "POST",
        API.ComplaintForm.SubmitCompForm,
        jsonData,
      );
      return response;
    } catch (error) {
      console.error("Error submitting complaint form:", error);
      throw error;
    }
  },

  DownloadFile: async (filePath) => {
    try {
      // Use the updated APIHelper with blob responseType for binary content
      const response = await APIHelper(
        "POST",
        API.FileDownload.DownloadFile,
        {
          filePath: filePath,
        },
        {
          responseType: "blob", // This tells axios to expect binary data
        },
      );

      return response; // This will be a Blob object
    } catch (error) {
      console.error("Error downloading file:", error);
      throw error;
    }
  },
};

export default IdeaGenFormService;
