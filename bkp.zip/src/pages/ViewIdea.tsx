import IdeaDetail from '@/components/IdeaDetail';

const ViewIdea = () => (
  <div className="p-4">
    <IdeaDetail />
  </div>
);

export default ViewIdea;
