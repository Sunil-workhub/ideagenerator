import Dashboard from '@/components/Dashboard';

const Index = () => (
  <div className="p-4">
    <Dashboard />
  </div>
);

export default Index;
